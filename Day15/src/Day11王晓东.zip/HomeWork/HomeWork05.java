package HomeWork;
//请计算3的5次幂
//	请计算3.2向上取整的结果
//	请计算3.8向下取整的结果
//	请计算5.6四舍五入取整的结果
public class HomeWork05 {
    public static void main(String[] args) {
        System.out.println(Math.pow(3,5));
        System.out.println(Math.ceil(3.2));
        System.out.println(Math.floor(3.8));
        System.out.println(Math.round(5.6));
    }
}
